In Last Update:-
Main Menu Bar Update
Animation Glitch Update