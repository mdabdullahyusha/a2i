
26-03-2022 Update:-
------------------

New 7 Page's Created,
    1) About US
    2) Press Media
    3) Press & Release
    3) News Paper
    3) Photo Gallery
    3) Press & Release Details
    3) Videos Page

Page's are Customized:-
------------------
Side Menu Page,
Header Menu,
Storys Page,
Story Details,
All Digital Centre Page,
Footer Customize In All Page.