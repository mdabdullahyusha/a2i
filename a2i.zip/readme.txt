In Last Update:-
data centre all page updated. (slider, partner slider)
index page menubar background edited.
contact form updated
team part on accourdion updated
team view icon updated
Case Studies Details page created (case_studies_details.html)
